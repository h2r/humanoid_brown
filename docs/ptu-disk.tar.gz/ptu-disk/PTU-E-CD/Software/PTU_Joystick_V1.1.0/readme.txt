/*************************************************************************
*****                    Pan-Tilt Tracking Mount                     *****
*****                      PTU_Joystick.exe                          *****
*****                       Version 1.00.00                          *****
*****                                                                *****
*****               (C)2011 FLIR Commercial Systems, Inc.            *****
*****                     All Rights Reserved.                       *****
*****                                                                *****
*****   Licensed users may freely distribute compiled code including *****
*****   this code and data. Source data and code may NOT be          *****
*****   distributed without the prior written consent from FLIR      *****
*****   Commercial Systems, Inc.                                     *****
*****                                                                *****
*****   FLIR Commercial Systems, Inc. reserves the right to make     *****
*****   changes without further notice to any content herein to      *****
*****   improve reliability, function or design. FLIR Commercial     *****
*****   Systems, Inc. shall not assume any liability arising from    *****
*****   the application or use of this code, data or function.       *****
*****                                                                *****
*****   FLIR Commercial Systems, Inc.                                *****
*****   Motion Control Systems                                       *****
*****   890C Cowan Rd, Burlingame, CA 94010                          *****
*****   www.flir.com/mcs                                             *****
*****   mcs-support@flir.com                                         *****
*************************************************************************/


Table of Contents:
A. Requirements
B. Installation Instructions
C. Known Issues
D. Additional Licensing



A.  Requirements

1) PC running Windows operating system.  This has been tested on 
Windows XP, Vista, and 7.  
2) Serial ports to communicate with PTU and cameras.  
3) Logitech Cordless RumblePad 2
4) Administrator privileges to PC to install software



2. Installation Instructions
A) Connect the RumblePad to your computer.  If the driver does not 
install automatically, visit www.logitech.com to download the correct 
driver for your operating system.
B) Install the SlimDX Runtime
This is included as 
SlimDX Runtime Net20 (June 2010).msi
The license agreement for SlimDX is reproduced in section D of this 
document.
If not included in your package, please download the Runtime from:
http://slimdx.org/download.php
C) Run the included program, PTU_Joystick.exe



3.  Known Issues
None.  Please contact FLIR MCS support @ mcs-support@flir.com if you 
find any bugs.



4.  Additional Licensing
PTU_Joystick makes use of the SlimDX runtime environment.  The license 
for this environment is copied below.

Copyright (c) 2007-2011 SlimDX Group

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.